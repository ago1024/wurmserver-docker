BEGIN TRANSACTION;
/* No creatures inserted on install. The server takes care of spawning */
COMMIT;
