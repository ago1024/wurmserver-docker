BEGIN TRANSACTION;
/* No players are created on install */
COMMIT;
